<?php
//connection with database
$insert=false;
if(isset($_POST['name'])){



$server="localhost";
$username="root";
$password="";
$con=mysqli_connect($server, $username, $password);
if(!$con)
{
    die("connection to this databse faild due to" .mysqli_connect_error());
}
//echo "success connecting to the db";
$name=$_POST['name'];
$gender=$_POST['gender'];
$age=$_POST['age'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$dis=$_POST['dis'];

$sql="INSERT INTO `form`.`form` ( `name`, `age`, `gender`, `email`, `mobile`, `info`, `date`) VALUES ('$name', '$age', '$gender', '$email', '$phone', '$dis', current_timestamp());";
//echo $sql;
//for inserting in database
if($con->query($sql)==true){
    //echo "successfully inserted";
    
    $insert= true;
}
else{
    echo "error: $sql <br> $con->error";
}
 $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            margin:0px;
            padding: 0px;
            box-sizing:border-box;
        }
        .container{
            
            text-align: center;
            width:800px;
            height:500px;
            margin: auto;
        }
        form{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
         }
         input,textarea{
             margin:10px;
             width: 400px;
             border: 1px solid black;
             border-radius: 10px;
             padding: 10px;
         }
         input{
             height:30px;
             
         }
        img{
            width: 100%;
            z-index: -1;
            position: absolute;
            opacity: 0.7;
        }
        .btn{
            border-radius: 10px;
            padding: 10px;
            background-color: darkkhaki;
            cursor: pointer;
            }
            .btn:hover{
                color:red;
            }
            h1 p{
                padding: 5px;
                margin: 5px;
            }
            .btn:active{
                color:blue
            }
            .submitMsg{
                color:red;
                font-size:24px;
            }

    </style>
</head>
<body>
    <img src="123.jfif" alt="">
    <div class="container">
    <h1>Welcome IIITian</h1>
    <p>Enter your details and submit this form</p>
    
    <?php
    //some changes
    if($insert==true){
    echo '<p class="submitMsg">Thanks for submitting</p>';
    }
    ?>
    <form action="form.php" method="post" onsubmit="return validation()">
        <input type="text" name="name" id="name" placeholder="Enter your full name" required>
        <span class="color" id="names"></span>
         <input type="text" name="age" id="age" placeholder="Enter your age" required>
         <span class="color" id="ages"></span>
     <input type="txt" name="gender" id="gender" placeholder="Enter your gender"required>
     <span class="color" id="genders"></span>
     
     <input type="email" name="email" id="email" placeholder="Enter your email"required>
     <span class="color" id="emails"></span>
       
     <input type="phone" name="phone" id="phone" placeholder="Enter your mobile number"required>
     <span class="color" id="phones"></span>
       
     <textarea name="dis" id="dis" cols="30" rows="10" placeholder="Enter any other information" required></textarea>
     <span class="color" id="dis"></span>
       
     <button class="btn">submit</button>
    
    </form>
    </div>
    <script>
            function validation() {
                var name = document.getElementById('name').value;
                var age = document.getElementById('age').value;
                var gender = document.getElementById('gender').value;
                var email = document.getElementById('email').value;
                var phone = document.getElementById('phone').value;
                var dis = document.getElementById('dis').value;
                if (name == "") {
                    document.getElementById('names').innerHTML = "** Please fill"
                    document.getElementById('name').style.border = "1px solid red"
                    return false;
                }
                if (name.length <= 2) {
                    document.getElementById('names').innerHTML = "** user name should be greater then two words."
                    document.getElementById('name').style.border = "1px solid red"
                    return false;
                }
                if (age == "") {
                    document.getElementById('ages').innerHTML = "** Please fill"
                    document.getElementById('age').style.border = "1px solid red"
                    return false;
                }
                if (isNaN(age)) {
                    document.getElementById('ages').innerHTML = "** Number Allowed"
                    document.getElementById('age').style.border = "1px solid red"
                    return false;
                }
                if (age < 5 && age > 25) {
                    document.getElementById('ages').innerHTML = "** age should be between 5 to 25"
                    document.getElementById('age').style.border = "1px solid red"
                    return false;
                }
                if (gender = "") {
                    document.getElementById('genders').innerHTML = "** Please fill"
                    document.getElementById('gender').style.border = "1px solid red"
                    return false;
                }
                if (email == "") {
                    document.getElementById('emails').innerHTML = "** Please fill"
                    document.getElementById('email').style.border = "1px solid red"
                    return false;
                }
                if (email.indexOf('@') <= 0) {
                    document.getElementById('emails').innerHTML = "** invalid email"
                    document.getElementById('email').style.border = "1px solid red"
                    return false;
                }
                if (isNaN(phone)){
                    document.getElementById('phones').innerHTML = "** Numbers are allowed";
                    document.getElementById('phone').style.border = "1px solid red"
                    return false;
                }
            }
        </script>
</body>
</html>